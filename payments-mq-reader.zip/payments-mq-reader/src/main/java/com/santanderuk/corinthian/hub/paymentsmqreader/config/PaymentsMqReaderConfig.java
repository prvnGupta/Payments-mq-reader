package com.santanderuk.corinthian.hub.paymentsmqreader.config;


import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Getter
@Configuration
public class PaymentsMqReaderConfig {

    @Value("${rabbitmq.host}")
    private String gassMqHost;

    @Value("${rabbitmq.paymentsqueue}")
    private String paymentsMqQueue;

    @Value("${rabbitmq.username}")
    private String mqUsername;

    @Value("${rabbitmq.password}")
    private String mqPassword;

    @Value("${rabbitmq.port}")
    private int mqPort;

    @Value("${rabbitmq.virtualhost}")
    private String virtualHost;

    @Value("${interval.readMq}")
    private int intervalReadMq;

    @Value("${interval.anmf}")
    private int anmfInterval;

    @Value("${payments.user}")
    private String eMergeUser;

    @Value("${payments.url}")
    private String paymentsUrl;

    @Value("${simulation.url}")
    private String simulationUrl;

    @Value("${maxMsg}")
    private int maxMsg;

}
