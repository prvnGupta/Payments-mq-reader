package com.santanderuk.corinthian.hub.paymentsmqreader.jwttoken;

import com.santanderuk.corinthian.hub.paymentsmqreader.config.TokenProviderConfig;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@ActiveProfiles("test")
public class FormUrlEncodedCreatorTest {

    @Mock
    TokenProviderConfig tokenProviderConfig;

    @Test
    public void test() {

        when(tokenProviderConfig.getGrantType()).thenReturn("grant_type_value");
        when(tokenProviderConfig.getClientId()).thenReturn("client_id_value");
        when(tokenProviderConfig.getScope()).thenReturn("scope_value");
        when(tokenProviderConfig.getUsername()).thenReturn("username_value");
        when(tokenProviderConfig.getPassword()).thenReturn("password_value");
        when(tokenProviderConfig.getClientIdSecret()).thenReturn("client_secret_value");

        FormUrlEncodedCreator formUrlEncodedCreator = new FormUrlEncodedCreator(tokenProviderConfig);

        assertEquals(createExpectedEncodedFormUrl(), formUrlEncodedCreator.get());

        assertEquals(createExpectedEncodedFormUrl().size(), formUrlEncodedCreator.get().size());
    }

    private MultiValueMap<String, String> createExpectedEncodedFormUrl() {
        MultiValueMap<String, String> map = new LinkedMultiValueMap<>();

        map.add("grant_type", "grant_type_value");
        map.add("client_id", "client_id_value");
        map.add("scope", "scope_value");
        map.add("username", "username_value");
        map.add("password", "password_value");
        map.add("client_secret", "client_secret_value");

        return map;
    }

}
