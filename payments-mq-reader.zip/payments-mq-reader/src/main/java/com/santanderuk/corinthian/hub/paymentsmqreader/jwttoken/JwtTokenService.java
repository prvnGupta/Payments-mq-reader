package com.santanderuk.corinthian.hub.paymentsmqreader.jwttoken;

import com.santanderuk.corinthian.hub.paymentsmqreader.config.TokenProviderConfig;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.util.Objects;

@Component
@Slf4j
public class JwtTokenService {

    private static final HttpStatus OK = HttpStatus.OK;
    private static final HttpMethod POST = HttpMethod.POST;
    private static final HttpMethod GET = HttpMethod.GET;

    private final HeaderCreator headerCreator;

    private final RestTemplate tokenRestTemplate;

    private final TokenProviderConfig tokenProviderConfig;

    private final FormUrlEncodedCreator formUrlEncodedCreator;

    public JwtTokenService(
            HeaderCreator headerCreator, RestTemplate tokenRestTemplate,
            TokenProviderConfig tokenProviderConfig, FormUrlEncodedCreator formUrlEncodedCreator) {

        this.headerCreator = headerCreator;
        this.tokenRestTemplate = tokenRestTemplate;
        this.tokenProviderConfig = tokenProviderConfig;
        this.formUrlEncodedCreator = formUrlEncodedCreator;
    }

    public String getToken() throws GeneralException {
        final String oAuth = getOAuthFromCredential();
        return getJwtTokenFromOAuth(oAuth);
    }

    private String getOAuthFromCredential() throws GeneralException {
        final ResponseEntity<OAuthFromCredentialResponse> response;
        try {
            response = callOAuthFromCredentials();
        } catch (Exception e) {
            log.error("Error while getting oAuth from credential");
            throw new GeneralException("AUTH_ERROR", "Error while getting oAuthFromCredential");
        }

        checkResponseForErrorsOAuthFromCredentials(response);

        return Objects.requireNonNull(response.getBody()).getAccessToken();
    }

    private String getJwtTokenFromOAuth(final String oAuth) throws GeneralException {
        final ResponseEntity<JwtFromOAuthResponse> response;
        try {
            response = callJwtFromOAuth(oAuth);
        } catch (Exception e) {
            log.error("Error while getting JWT from oAuth token");
            throw new GeneralException("JWT_ERROR", "Error while getting Jwt from oAuth");
        }

        checkResponseForErrorsJwtFromOAuth(response);

        return Objects.requireNonNull(response.getBody()).getToken();
    }

    private ResponseEntity<OAuthFromCredentialResponse> callOAuthFromCredentials() {
        final String url = tokenProviderConfig.getOAuthFromCredentials();
        final HttpHeaders headers = headerCreator.oAuthFromCredentials();
        final MultiValueMap<String, String> asMap = formUrlEncodedCreator.get();
        final HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(asMap, headers);

        return tokenRestTemplate.exchange(
                url, POST, request, OAuthFromCredentialResponse.class);
    }

    private ResponseEntity<JwtFromOAuthResponse> callJwtFromOAuth(final String oAuth) {
        final String url = tokenProviderConfig.getJwtFromOAuthUrl();
        final HttpHeaders header = headerCreator.jwtFromOauth(oAuth);
        final HttpEntity httpEntity = new HttpEntity(header);

        return tokenRestTemplate.exchange(url, GET, httpEntity, JwtFromOAuthResponse.class);
    }

    private void checkResponseForErrorsOAuthFromCredentials(
            ResponseEntity<OAuthFromCredentialResponse> response) throws GeneralException {

        final HttpStatus statusCode = response.getStatusCode();
        if (statusCode != OK) {
            log.error("Error while getting oAuth from credential");
            throw new GeneralException("AUTH_ERROR", "Error while getting oAuthFromCredential");
        }
    }

    private void checkResponseForErrorsJwtFromOAuth(
            ResponseEntity<JwtFromOAuthResponse> response) throws GeneralException {

        final HttpStatus statusCode = response.getStatusCode();
        if (statusCode != HttpStatus.OK) {
            log.error("Error while getting JWT from oAuth token");
            throw new GeneralException("JWT_ERROR", "Error while getting Jwt from oAuth");
        }
    }

}
