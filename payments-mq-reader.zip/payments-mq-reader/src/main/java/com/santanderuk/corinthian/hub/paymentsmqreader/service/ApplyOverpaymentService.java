package com.santanderuk.corinthian.hub.paymentsmqreader.service;

import com.santanderuk.corinthian.hub.paymentsmqreader.config.PaymentsMqReaderConfig;
import com.santanderuk.corinthian.services.commons.anmfclient.io.applyoverpaymenttransaction.ApplyOverpaymentRequest;
import com.santanderuk.corinthian.services.commons.anmfclient.io.simulations.ANMFSimulationRequest;
import com.santanderuk.corinthian.services.commons.anmfclient.io.simulations.ANMFSimulationResponse;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class ApplyOverpaymentService {
    private final MqSimulationClient mqSimulationClient;
    private final MqApplyOverpaymentClient mqApplyOverpaymentClient;
    private final PaymentsMqReaderConfig config;

    @Autowired
    public ApplyOverpaymentService(MqSimulationClient mqSimulationClient, MqApplyOverpaymentClient mqApplyOverpaymentClient, PaymentsMqReaderConfig config) {
        this.mqSimulationClient = mqSimulationClient;
        this.mqApplyOverpaymentClient = mqApplyOverpaymentClient;
        this.config = config;
    }

    public boolean apply(PaymentsMqMessage paymentsMqMessage, String jwtToken) throws ConnectionException {
        log.info("making call to simulation v2");
        ANMFSimulationResponse simulationV2Response = mqSimulationClient.simulate(config.getSimulationUrl(), paymentsMqMessage.getAnmfSimulationRequest(), AnmfRegion.A, jwtToken);
        int simulationIdV2 = simulationV2Response.getOverpaymentSimulationResponse().getOutputStruc().getOSimulationId();

        log.info("making call to update payment method v2");
        ANMFSimulationRequest updatePaymentMethodRequest = generateUpdatePaymentMethodRequest(paymentsMqMessage, simulationIdV2);
        mqSimulationClient.simulate(config.getSimulationUrl(), updatePaymentMethodRequest, AnmfRegion.A, jwtToken);

        log.info("making call to apply overpayment");
        ApplyOverpaymentRequest applyOverpaymentRequest = generateApplyPaymentRequest(paymentsMqMessage, simulationIdV2);
        mqApplyOverpaymentClient.pay(config.getPaymentsUrl(), applyOverpaymentRequest, config.getEMergeUser(), jwtToken);

        return true;
    }

    private ApplyOverpaymentRequest generateApplyPaymentRequest(PaymentsMqMessage paymentsMqMessage, int simulationIdV2) {
        ApplyOverpaymentRequest applyOverpaymentRequest = paymentsMqMessage.getApplyOverpaymentRequest();
        applyOverpaymentRequest.getCreateWsPayReceivedRequest().getRequest().getInputStruct().getIo32129().setISimulatorId(simulationIdV2);
        return applyOverpaymentRequest;
    }

    private ANMFSimulationRequest generateUpdatePaymentMethodRequest(PaymentsMqMessage paymentsMqMessage, int simulationIdV2) {
        ANMFSimulationRequest updatePaymentMethodRequest = paymentsMqMessage.getAnmfUpdateSimulationRequest();
        updatePaymentMethodRequest.getOverpaymentSimulationRequest().getInputStruc().setISimulationId(simulationIdV2);
        return updatePaymentMethodRequest;
    }
}
