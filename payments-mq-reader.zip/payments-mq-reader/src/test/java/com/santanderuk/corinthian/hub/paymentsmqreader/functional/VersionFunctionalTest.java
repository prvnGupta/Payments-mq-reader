package com.santanderuk.corinthian.hub.paymentsmqreader.functional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.context.ActiveProfiles;

import static com.jayway.restassured.RestAssured.given;

@ActiveProfiles("test")
public class VersionFunctionalTest extends FunctionalTest {

    String versionUrl;

    @BeforeEach
    public void setup() {
        versionUrl = String.format("http://localhost:%s/payments-mq-reader/version", serverPort);
    }

    @Test
    public void customVersionReturnsUp() {

        given().
                when().
                get(versionUrl).
                then().
                statusCode(200);

    }

}
