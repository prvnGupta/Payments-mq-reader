package com.santanderuk.corinthian.hub.paymentsmqreader.jwttoken;

import com.santanderuk.corinthian.hub.paymentsmqreader.config.TokenProviderConfig;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.*;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@ActiveProfiles("test")
public class JwtTokenServiceTest {

    private static final MediaType APPLICATION_FORM_URLENCODED = MediaType.APPLICATION_FORM_URLENCODED;
    private static final MediaType APPLICATION_JSON = MediaType.APPLICATION_JSON;
    private static final HttpStatus BAD_REQUEST = HttpStatus.BAD_REQUEST;
    private static final HttpStatus UNAUTHORIZED = HttpStatus.UNAUTHORIZED;
    private static final HttpStatus OK = HttpStatus.OK;

    JwtTokenService jwtToken;

    @Mock
    HeaderCreator headerCreator;

    @Mock
    RestTemplate restTemplate;

    @Mock
    TokenProviderConfig tokenProviderConfig;

    @Mock
    FormUrlEncodedCreator formUrlEncodedCreator;

    @BeforeEach
    void setUp() {
        jwtToken = new JwtTokenService(headerCreator, restTemplate, tokenProviderConfig, formUrlEncodedCreator);
    }

    @Test
    public void testOk() throws GeneralException {

        when(tokenProviderConfig.getJwtFromOAuthUrl()).thenReturn("http://jwtFromOauth");
        when(tokenProviderConfig.getOAuthFromCredentials()).thenReturn("http://oAuthFromCredential");

        when(headerCreator.jwtFromOauth(anyString())).thenReturn(createHeaderForJwtFromOauth());
        when(headerCreator.oAuthFromCredentials()).thenReturn(createHeaderForOAuthFromCredential());

        when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), eq(OAuthFromCredentialResponse.class))).thenReturn(createOkResponseForOAuthFromCredentials());
        when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), eq(JwtFromOAuthResponse.class))).thenReturn(createOkResponseForJwtFromOAuth());

        when(formUrlEncodedCreator.get()).thenReturn(createFormUrlEncoded());


        assertEquals("jwtToken", jwtToken.getToken());
    }

    @Test
    public void test_OAuthFromCredentialsServiceFailsMiserably() {

        mockForOAuthFromCredentialsThrowingRestClientException();

        GeneralException generalException = assertThrows(GeneralException.class, () -> jwtToken.getToken());
        assertEquals("AUTH_ERROR", generalException.getCode());
        assertEquals("Error while getting oAuthFromCredential", generalException.getMessage());
    }

    @Test
    public void test_JwtFromOAuthServiceFailsMiserably() {

        mockForJwtFromOAuthThrowingRestClientException();

        GeneralException generalException = assertThrows(GeneralException.class, () -> jwtToken.getToken());
        assertEquals("JWT_ERROR", generalException.getCode());
        assertEquals("Error while getting Jwt from oAuth", generalException.getMessage());
    }

    @Test
    public void test_OAuthFromCredentialsServiceReturns400() {

        mockForOAuthFromCredentialsReturns400();

        GeneralException generalException = assertThrows(GeneralException.class, () -> jwtToken.getToken());
        assertEquals("AUTH_ERROR", generalException.getCode());
        assertEquals("Error while getting oAuthFromCredential", generalException.getMessage());
    }

    @Test
    public void test_JwtFromOAuthServiceReturns400() {

        mockForJwtFromOAuthReturns400();

        GeneralException generalException = assertThrows(GeneralException.class, () -> jwtToken.getToken());
        assertEquals("JWT_ERROR", generalException.getCode());
        assertEquals("Error while getting Jwt from oAuth", generalException.getMessage());
    }

    @Test
    public void test_OAuthFromCredentialsServiceReturns401() {

        mockForOAuthFromCredentialsReturns401();

        GeneralException generalException = assertThrows(GeneralException.class, () -> jwtToken.getToken());
        assertEquals("AUTH_ERROR", generalException.getCode());
        assertEquals("Error while getting oAuthFromCredential", generalException.getMessage());
    }

    @Test
    public void test_JwtFromOAuthServiceReturns401() {

        mockForJwtFromOAuthReturns401();

        GeneralException generalException = assertThrows(GeneralException.class, () -> jwtToken.getToken());
        assertEquals("JWT_ERROR", generalException.getCode());
        assertEquals("Error while getting Jwt from oAuth", generalException.getMessage());
    }


    private void mockForJwtFromOAuthThrowingRestClientException() {
        when(tokenProviderConfig.getJwtFromOAuthUrl()).thenReturn("http://jwtFromOauth");
        when(tokenProviderConfig.getOAuthFromCredentials()).thenReturn("http://oAuthFromCredential");

        when(headerCreator.jwtFromOauth(anyString())).thenReturn(createHeaderForJwtFromOauth());
        when(headerCreator.oAuthFromCredentials()).thenReturn(createHeaderForOAuthFromCredential());

        when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), eq(OAuthFromCredentialResponse.class))).thenReturn(createOkResponseForOAuthFromCredentials());

        when(formUrlEncodedCreator.get()).thenReturn(createFormUrlEncoded());
        when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), eq(JwtFromOAuthResponse.class))).thenThrow(RestClientException.class);
    }

    private void mockForOAuthFromCredentialsThrowingRestClientException() {
        when(tokenProviderConfig.getOAuthFromCredentials()).thenReturn("http://oAuthFromCredential");
        when(headerCreator.oAuthFromCredentials()).thenReturn(createHeaderForOAuthFromCredential());
        when(formUrlEncodedCreator.get()).thenReturn(createFormUrlEncoded());
        when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), eq(OAuthFromCredentialResponse.class))).thenThrow(RestClientException.class);
    }

    private void mockForOAuthFromCredentialsReturns400() {
        when(tokenProviderConfig.getOAuthFromCredentials()).thenReturn("http://oAuthFromCredential");

        when(headerCreator.oAuthFromCredentials()).thenReturn(createHeaderForOAuthFromCredential());

        when(formUrlEncodedCreator.get()).thenReturn(createFormUrlEncoded());
        ResponseEntity<OAuthFromCredentialResponse> responseEntity = new ResponseEntity<>(null, BAD_REQUEST);
        when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), eq(OAuthFromCredentialResponse.class))).thenReturn(responseEntity);

    }

    private void mockForJwtFromOAuthReturns400() {
        when(tokenProviderConfig.getJwtFromOAuthUrl()).thenReturn("http://jwtFromOauth");
        when(tokenProviderConfig.getOAuthFromCredentials()).thenReturn("http://oAuthFromCredential");

        when(headerCreator.jwtFromOauth(anyString())).thenReturn(createHeaderForJwtFromOauth());
        when(headerCreator.oAuthFromCredentials()).thenReturn(createHeaderForOAuthFromCredential());

        when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), eq(OAuthFromCredentialResponse.class))).thenReturn(createOkResponseForOAuthFromCredentials());

        when(formUrlEncodedCreator.get()).thenReturn(createFormUrlEncoded());
        ResponseEntity<JwtFromOAuthResponse> responseEntity = new ResponseEntity<>(null, BAD_REQUEST);
        when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), eq(JwtFromOAuthResponse.class))).thenReturn(responseEntity);
    }

    private void mockForOAuthFromCredentialsReturns401() {
        when(tokenProviderConfig.getOAuthFromCredentials()).thenReturn("http://oAuthFromCredential");

        when(headerCreator.oAuthFromCredentials()).thenReturn(createHeaderForOAuthFromCredential());

        when(formUrlEncodedCreator.get()).thenReturn(createFormUrlEncoded());
        OAuthFromCredentialResponse response = new OAuthFromCredentialResponse();
        response.setError("invalid_something");
        ResponseEntity<OAuthFromCredentialResponse> responseEntity = new ResponseEntity<>(response, UNAUTHORIZED);
        when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), eq(OAuthFromCredentialResponse.class))).thenReturn(responseEntity);

    }

    private void mockForJwtFromOAuthReturns401() {
        when(tokenProviderConfig.getJwtFromOAuthUrl()).thenReturn("http://jwtFromOauth");
        when(tokenProviderConfig.getOAuthFromCredentials()).thenReturn("http://oAuthFromCredential");

        when(headerCreator.jwtFromOauth(anyString())).thenReturn(createHeaderForJwtFromOauth());
        when(headerCreator.oAuthFromCredentials()).thenReturn(createHeaderForOAuthFromCredential());

        when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), eq(OAuthFromCredentialResponse.class))).thenReturn(createOkResponseForOAuthFromCredentials());

        when(formUrlEncodedCreator.get()).thenReturn(createFormUrlEncoded());
        ResponseEntity<JwtFromOAuthResponse> responseEntity = new ResponseEntity<>(null, UNAUTHORIZED);
        when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), eq(JwtFromOAuthResponse.class))).thenReturn(responseEntity);
    }


    private ResponseEntity<OAuthFromCredentialResponse> createOkResponseForOAuthFromCredentials() {
        OAuthFromCredentialResponse response = new OAuthFromCredentialResponse();
        response.setTokenType("token_type_value");
        response.setAccessToken("access_token_value");
        response.setExpiresIn(3600);
        response.setConsentedOn(1559220734);
        response.setScope("anmf.read");
        response.setRefreshToken("refresh_token_value");
        response.setRefreshTokenExpiresIn(2682000);

        return new ResponseEntity<>(response, HttpStatus.OK);

    }

    private MultiValueMap<String, String> createFormUrlEncoded() {
        MultiValueMap<String, String> map = new LinkedMultiValueMap<>();

        map.add("grant_type", "grant_type_value");
        map.add("client_id", "client_id_value");
        map.add("scope", "scope_value");
        map.add("username", "username_value");
        map.add("password", "password_value");
        map.add("client_secret", "client_secret_value");

        return map;
    }

    private HttpHeaders createHeaderForOAuthFromCredential() {
        final HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.setContentType(APPLICATION_FORM_URLENCODED);
        httpHeaders.add("authorization", "Bearer oAuthToken");
        httpHeaders.add("X-IBM-Client-Id", "xIbmClientIdValue");

        return httpHeaders;
    }

    private ResponseEntity<JwtFromOAuthResponse> createOkResponseForJwtFromOAuth() {
        JwtFromOAuthResponse response = new JwtFromOAuthResponse();
        response.setToken("jwtToken");
        response.setHeaderJwt(new HeaderJwt());
        response.setPayloadJwt(new PayloadJwt());

        return new ResponseEntity<>(response, OK);
    }

    private HttpHeaders createHeaderForJwtFromOauth() {
        final HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.setContentType(APPLICATION_JSON);
        httpHeaders.add("authorization", "Bearer oAuthToken");
        httpHeaders.add("X-IBM-Client-Id", "xIbmClientIdValue");

        return httpHeaders;
    }

}
