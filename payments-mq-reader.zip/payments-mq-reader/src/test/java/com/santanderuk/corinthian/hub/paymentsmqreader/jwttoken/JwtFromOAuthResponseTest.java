package com.santanderuk.corinthian.hub.paymentsmqreader.jwttoken;

import org.junit.jupiter.api.Test;
import org.springframework.test.context.ActiveProfiles;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;

@ActiveProfiles("test")
public class JwtFromOAuthResponseTest {

    @Test
    public void testFields() {
        JwtFromOAuthResponse response = new JwtFromOAuthResponse();

        response.setToken("token_value");

        assertEquals("token_value", response.getToken());

        HeaderJwt headerJwt = new HeaderJwt();
        headerJwt.setAlg("alg_value");
        headerJwt.setTyp("typ_value");
        headerJwt.setKid("kid_value");

        response.setHeaderJwt(headerJwt);

        assertEquals("alg_value", response.getHeaderJwt().getAlg());
        assertEquals("typ_value", response.getHeaderJwt().getTyp());
        assertEquals("kid_value", response.getHeaderJwt().getKid());

        PayloadJwt payloadJwt = new PayloadJwt();

        payloadJwt.setIss("iss_value");
        payloadJwt.setSub("sub_value");
        payloadJwt.setAud(new String[]{"value1", "value2"});
        payloadJwt.setNbf("nbf_value");
        payloadJwt.setExp("exp_value");
        payloadJwt.setIat("iat_value");
        payloadJwt.setJti("jti_value");

        response.setPayloadJwt(payloadJwt);

        assertEquals("iss_value", response.getPayloadJwt().getIss());
        assertEquals("sub_value", response.getPayloadJwt().getSub());
        assertArrayEquals(new String[]{"value1", "value2"}, response.getPayloadJwt().getAud());
        assertEquals("nbf_value", response.getPayloadJwt().getNbf());
        assertEquals("exp_value", response.getPayloadJwt().getExp());
        assertEquals("iat_value", response.getPayloadJwt().getIat());
        assertEquals("jti_value", response.getPayloadJwt().getJti());


        assertEquals("{\"headerJwt\":{\"alg\":\"alg_value\",\"kid\":\"kid_value\",\"typ\":\"typ_value\"},\"payloadJwt\":{\"aud\":[\"value1\",\"value2\"],\"exp\":\"exp_value\",\"iat\":\"iat_value\",\"iss\":\"iss_value\",\"jti\":\"jti_value\",\"nbf\":\"nbf_value\",\"sub\":\"sub_value\"},\"token\":\"token_value\"}", response.toString());

    }
}
