package com.santanderuk.corinthian.hub.paymentsmqreader;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Created by c0245070 on 08/09/2017.
 */
@SpringBootApplication
public class PaymentsMqReaderApplicationTest {


    public static void main(String[] args) {
        System.out.println("HERE");
        //SpringApplication app = new SpringApplication(PaymentsMqReaderApplicationTest.class);
        SpringApplication.run(PaymentsMqReaderApplicationTest.class, args);

    }


}
