package com.santanderuk.corinthian.hub.paymentsmqreader.service;

import com.santanderuk.corinthian.hub.paymentsmqreader.config.PaymentsMqReaderConfig;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.HeartBeatClient;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.Mockito.*;


@ExtendWith(MockitoExtension.class)
class PaymentsMqReaderServiceTest {

    PaymentsMqReaderService service;

    @Mock
    MqConsumerService mqConsumerService;

    @Mock
    PaymentsMqReaderConfig paymentsMqReaderConfig;
    @Mock
    HeartBeatClient heartBeatClient;


    @BeforeEach
    void setUp() {
        service = new PaymentsMqReaderService(paymentsMqReaderConfig, mqConsumerService, heartBeatClient);
    }

    @Test
    void happyPathRegionA() throws GeneralException, InterruptedException {
        when(heartBeatClient.fetchCurrentRegion()).thenReturn(AnmfRegion.A);
        service.executeLogic();
        verify(mqConsumerService, times(1)).readMessage();
    }

    @Test
    void happyPathRegionW() throws GeneralException, InterruptedException {
        when(heartBeatClient.fetchCurrentRegion()).thenReturn(AnmfRegion.W);
        service.executeLogic();
        verify(mqConsumerService, times(0)).readMessage();
    }
}
