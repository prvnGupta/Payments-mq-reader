package com.santanderuk.corinthian.hub.paymentsmqreader.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.HeartBeatClient;
import com.santanderuk.corinthian.services.commons.config.ApiManagerConfig;
import lombok.Getter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

@Configuration
@Getter
public class BeanConfig {
    @Bean
    RestTemplate restTemplate() {
        return new RestTemplate();
    }

    @Bean
    HeartBeatClient heartBeatClient() {
        return new HeartBeatClient();
    }

    @Bean
    ObjectMapper objectMapper() {
        return new ObjectMapper();
    }

    @Bean
    ApiManagerConfig apiManagerConfig() {
        return new ApiManagerConfig();
    }

}
