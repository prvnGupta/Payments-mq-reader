package com.santanderuk.corinthian.hub.paymentsmqreader.jwttoken;

import com.santanderuk.corinthian.hub.paymentsmqreader.config.TokenProviderConfig;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@ActiveProfiles("test")
public class HeaderCreatorTest {

    private static final MediaType APPLICATION_JSON = MediaType.APPLICATION_JSON;
    private static final MediaType APPLICATION_FORM_URLENCODED = MediaType.APPLICATION_FORM_URLENCODED;

    @Mock
    TokenProviderConfig tokenProviderConfig;

    @Test
    public void test_headerForJwtFromOAuth() {

        when(tokenProviderConfig.getClientId()).thenReturn("xIbmClientIdValue");

        HeaderCreator creator = new HeaderCreator(tokenProviderConfig);

        HttpHeaders expectedHeaders = new HttpHeaders();
        expectedHeaders.setContentType(APPLICATION_JSON);
        expectedHeaders.add("authorization", "Bearer oAuthToken");
        expectedHeaders.add("x-ibm-client-id", "xIbmClientIdValue");

        assertEquals(expectedHeaders, creator.jwtFromOauth("oAuthToken"));
        assertEquals(expectedHeaders.size(), creator.jwtFromOauth("oAuthToken").size());
    }

    @Test
    public void test_headerForOAuthFromCredentials() {

        HeaderCreator creator = new HeaderCreator(tokenProviderConfig);

        HttpHeaders expectedHeaders = new HttpHeaders();
        expectedHeaders.setContentType(APPLICATION_FORM_URLENCODED);

        assertEquals(expectedHeaders, creator.oAuthFromCredentials());
        assertEquals(expectedHeaders.size(), creator.oAuthFromCredentials().size());

    }

}
