package com.santanderuk.corinthian.hub.paymentsmqreader.service;


import com.santanderuk.corinthian.hub.paymentsmqreader.config.PaymentsMqReaderConfig;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.HeartBeatClient;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static java.lang.Thread.sleep;

@Service
@Slf4j
public class PaymentsMqReaderService implements Runnable {

    private final PaymentsMqReaderConfig paymentsMqReaderConfig;
    private final MqConsumerService mqConsumerService;

    private final HeartBeatClient heartBeatClient;

    @Autowired
    public PaymentsMqReaderService(PaymentsMqReaderConfig paymentsMqReaderConfig, MqConsumerService mqConsumerService, HeartBeatClient heartBeatClient) {
        this.paymentsMqReaderConfig = paymentsMqReaderConfig;
        this.mqConsumerService = mqConsumerService;
        this.heartBeatClient = heartBeatClient;
    }

    @Override
    public void run() {
        try {
            listen();
        } catch (GeneralException e) {
            log.error("ERROR:- Whilst calling listen", e);
            Thread.currentThread().interrupt();
        }
    }

    public void listen() throws GeneralException {
        try {
            while (paymentsMqReaderConfig.getIntervalReadMq() > 0) {
                executeLogic();
            }
        } catch (InterruptedException e) {
            log.error("ERROR:- Interrupted Exception caught", e);
            Thread.currentThread().interrupt();
        } catch (Exception e) {
            log.error("ERROR:- Whilst calling listen", e);
            throw new GeneralException("9999", "Unknown Error while calling listener from PaymentsMqReaderService");
        }
    }

    public void executeLogic() throws InterruptedException, GeneralException {
        if (regionAAvailable()) {
            log.info("Region A. Checking if there are messages in the queue");
            mqConsumerService.readMessage();

        } else {
            log.info("Region A not available.");
        }
        int redisInterval = paymentsMqReaderConfig.getIntervalReadMq();
        log.info("Sleeping for {} milliseconds", redisInterval);
        sleep(redisInterval);
    }

    private boolean regionAAvailable() {
        String region = "x";
        log.info("Checking available region...");
        try {
            region = heartBeatClient.fetchCurrentRegion().toString();
        } catch (Exception e) {
            log.error("Error while connecting to heart beat service", e);
        }
        log.info("{} region available", region);
        return "a".equalsIgnoreCase(region);
    }
}
