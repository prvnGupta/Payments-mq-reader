package com.santanderuk.corinthian.hub.paymentsmqreader.service;

import com.santanderuk.corinthian.hub.paymentsmqreader.TestDataCreator;
import com.santanderuk.corinthian.services.commons.anmfclient.io.simulations.ANMFSimulationRequest;
import com.santanderuk.corinthian.services.commons.anmfclient.io.simulations.ANMFSimulationResponse;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.config.ApiManagerConfig;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Objects;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class MqSimulationClientTest {
    MqSimulationClient mqSimulationClient;

    @Mock
    RestTemplate restTemplate;

    @Mock
    ApiManagerConfig apiManagerConfig;

    @BeforeEach
    void setUp() {
        mqSimulationClient = new MqSimulationClient(restTemplate, apiManagerConfig);
        when(apiManagerConfig.getClientIdValue()).thenReturn("clientId");
        when(apiManagerConfig.getClientSecretValue()).thenReturn("clientSecret");
    }

    @Test
    void testHappyPath() throws ConnectionException, IOException {
        ArgumentCaptor<HttpEntity> argumentCaptorHttpEntity = ArgumentCaptor.forClass(HttpEntity.class);

        when(restTemplate.postForEntity(anyString(), any(HttpEntity.class), eq(ANMFSimulationResponse.class))).thenReturn(generateOKResponseEntity());
        ANMFSimulationResponse simulationResponse = mqSimulationClient.simulate("simulationUrl/simulation", new ANMFSimulationRequest(), AnmfRegion.A, "jwtToken");
        Mockito.verify(restTemplate, times(1)).postForEntity(anyString(), argumentCaptorHttpEntity.capture(), eq(ANMFSimulationResponse.class));
        assertEquals("A", Objects.requireNonNull(argumentCaptorHttpEntity.getValue().getHeaders().get("Region")).get(0));


        assertEquals(6983663, simulationResponse.getOverpaymentSimulationResponse().getOutputStruc().getOSimulationId());
        assertEquals(new BigDecimal("36410.89"), simulationResponse.getOverpaymentSimulationResponse().getOutputStruc().getOCapBalAftSim());
        assertEquals(new BigDecimal("8679.77"), simulationResponse.getOverpaymentSimulationResponse().getOutputStruc().getOLoanData().get(0).getOLnIntAftSim());
    }

    @Test
    void testWeMapRegionAsAHeader() throws ConnectionException, IOException {
        ArgumentCaptor<HttpEntity> argumentCaptorHttpEntity = ArgumentCaptor.forClass(HttpEntity.class);

        when(restTemplate.postForEntity(anyString(), any(HttpEntity.class), eq(ANMFSimulationResponse.class))).thenReturn(generateOKResponseEntity());
        ANMFSimulationResponse simulationResponse = mqSimulationClient.simulate("simulationUrl/simulation", new ANMFSimulationRequest(), AnmfRegion.W, "jwtToken");
        Mockito.verify(restTemplate, times(1)).postForEntity(anyString(), argumentCaptorHttpEntity.capture(), eq(ANMFSimulationResponse.class));
        assertEquals("W", Objects.requireNonNull(argumentCaptorHttpEntity.getValue().getHeaders().get("Region")).get(0));
        assertEquals("jwtToken", Objects.requireNonNull(argumentCaptorHttpEntity.getValue().getHeaders().get("Authorization")).get(0));
        assertEquals(6983663, simulationResponse.getOverpaymentSimulationResponse().getOutputStruc().getOSimulationId());
        assertEquals(new BigDecimal("36410.89"), simulationResponse.getOverpaymentSimulationResponse().getOutputStruc().getOCapBalAftSim());
        assertEquals(new BigDecimal("8679.77"), simulationResponse.getOverpaymentSimulationResponse().getOutputStruc().getOLoanData().get(0).getOLnIntAftSim());
    }

    @Test
    void testSimulationRestClientExc() {
        when(restTemplate.postForEntity(anyString(), any(HttpEntity.class), eq(ANMFSimulationResponse.class))).thenThrow(RestClientException.class);
        assertThrows(ConnectionException.class, () -> mqSimulationClient.simulate("simulationUrl/simulation", new ANMFSimulationRequest(), AnmfRegion.A, "jwtToken"));
    }

    @Test
    void testSimulationErrorBody() throws ConnectionException, IOException {
        when(restTemplate.postForEntity(anyString(), any(HttpEntity.class), eq(ANMFSimulationResponse.class))).thenReturn(generateKoResponseEntity());
        ANMFSimulationResponse simulationResponse = mqSimulationClient.simulate("simulationUrl/simulation", new ANMFSimulationRequest(), AnmfRegion.A, "jwtToken");

        assertEquals(0, simulationResponse.getOverpaymentSimulationResponse().getOutputStruc().getOSimulationId());
        assertEquals("MBSOSIMU", simulationResponse.getOverpaymentSimulationResponse().getOutputStruc().getEStruc().getEProgname());
        assertEquals("ERRWSSAP", simulationResponse.getOverpaymentSimulationResponse().getOutputStruc().getEStruc().getECode());
    }

    private ResponseEntity<ANMFSimulationResponse> generateOKResponseEntity() throws IOException {
        ANMFSimulationResponse anmfSimulationResponse = TestDataCreator.generateSimulationResponseOK();
        return new ResponseEntity<>(anmfSimulationResponse, HttpStatus.OK);
    }

    private ResponseEntity<ANMFSimulationResponse> generateKoResponseEntity() throws IOException {
        ANMFSimulationResponse anmfSimulationResponse = TestDataCreator.generateSimulationResponseKo();
        return new ResponseEntity<>(anmfSimulationResponse, HttpStatus.OK);
    }
}
