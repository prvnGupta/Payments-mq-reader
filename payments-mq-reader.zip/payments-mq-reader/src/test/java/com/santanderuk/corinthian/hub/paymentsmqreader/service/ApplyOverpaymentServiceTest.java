package com.santanderuk.corinthian.hub.paymentsmqreader.service;

import com.santanderuk.corinthian.hub.paymentsmqreader.TestDataCreator;
import com.santanderuk.corinthian.hub.paymentsmqreader.config.PaymentsMqReaderConfig;
import com.santanderuk.corinthian.services.commons.anmfclient.io.applyoverpaymenttransaction.ApplyOverpaymentRequest;
import com.santanderuk.corinthian.services.commons.anmfclient.io.simulations.ANMFSimulationRequest;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ApplyOverpaymentServiceTest {

    ApplyOverpaymentService applyOverpaymentService;
    @Mock
    MqSimulationClient mqSimulationClient;
    @Mock
    MqApplyOverpaymentClient mqApplyOverpaymentClient;
    @Mock
    PaymentsMqReaderConfig config;
    private String simulationUrl;
    private String paymentsUrl;

    @BeforeEach
    void setUp() {
        simulationUrl = "/sanuk/internal/mortgage-payments/simulation";
        paymentsUrl = "/sanuk/internal/mortgage-payments/payments";
        when(config.getEMergeUser()).thenReturn("eMergeUser");
        when(config.getSimulationUrl()).thenReturn(simulationUrl);
        when(config.getPaymentsUrl()).thenReturn(paymentsUrl);
        applyOverpaymentService = new ApplyOverpaymentService(mqSimulationClient, mqApplyOverpaymentClient, config);
    }

    @Test
    void testWeMakeThe3Calls() throws IOException, ConnectionException {

        ArgumentCaptor<ANMFSimulationRequest> anmfSimulationRequestArgumentCaptor = ArgumentCaptor.forClass(ANMFSimulationRequest.class);
        ArgumentCaptor<ApplyOverpaymentRequest> applyOverpaymentRequestArgumentCaptor = ArgumentCaptor.forClass(ApplyOverpaymentRequest.class);

        when(mqSimulationClient.simulate(anyString(), any(ANMFSimulationRequest.class), any(AnmfRegion.class), anyString())).thenReturn(TestDataCreator.generateSimulationResponseOK());
        doNothing().when(mqApplyOverpaymentClient).pay(anyString(), any(ApplyOverpaymentRequest.class), anyString(), anyString());

        assertTrue(applyOverpaymentService.apply(TestDataCreator.generatPaymentsMqMessage(), "jwtToken"));

        verify(mqSimulationClient, times(2)).simulate(eq(simulationUrl), anmfSimulationRequestArgumentCaptor.capture(), eq(AnmfRegion.A), eq("jwtToken"));
        verify(mqApplyOverpaymentClient, times(1)).pay(eq(paymentsUrl), applyOverpaymentRequestArgumentCaptor.capture(), eq("eMergeUser"), eq("jwtToken"));

        assertEquals(0, anmfSimulationRequestArgumentCaptor.getAllValues().get(0).getOverpaymentSimulationRequest().getInputStruc().getISimulationId());
        assertEquals(6983663, anmfSimulationRequestArgumentCaptor.getAllValues().get(1).getOverpaymentSimulationRequest().getInputStruc().getISimulationId());
        assertEquals(6983663, applyOverpaymentRequestArgumentCaptor.getValue().getCreateWsPayReceivedRequest().getRequest().getInputStruct().getIo32129().getISimulatorId());

    }

    @Test
    void testTrueIfApplyPaymentFails() throws IOException, ConnectionException {

        ArgumentCaptor<ANMFSimulationRequest> anmfSimulationRequestArgumentCaptor = ArgumentCaptor.forClass(ANMFSimulationRequest.class);
        ArgumentCaptor<ApplyOverpaymentRequest> applyOverpaymentRequestArgumentCaptor = ArgumentCaptor.forClass(ApplyOverpaymentRequest.class);

        when(mqSimulationClient.simulate(anyString(), any(ANMFSimulationRequest.class), any(AnmfRegion.class), anyString())).thenReturn(TestDataCreator.generateSimulationResponseOK());
        doNothing().when(mqApplyOverpaymentClient).pay(anyString(), any(ApplyOverpaymentRequest.class), anyString(), anyString());

        assertTrue(applyOverpaymentService.apply(TestDataCreator.generatPaymentsMqMessage(), "jwtToken"));

        verify(mqSimulationClient, times(2)).simulate(eq(simulationUrl), anmfSimulationRequestArgumentCaptor.capture(), eq(AnmfRegion.A), eq("jwtToken"));
        verify(mqApplyOverpaymentClient, times(1)).pay(eq(paymentsUrl), applyOverpaymentRequestArgumentCaptor.capture(), eq("eMergeUser"), eq("jwtToken"));

        assertEquals(0, anmfSimulationRequestArgumentCaptor.getAllValues().get(0).getOverpaymentSimulationRequest().getInputStruc().getISimulationId());
        assertEquals(6983663, anmfSimulationRequestArgumentCaptor.getAllValues().get(1).getOverpaymentSimulationRequest().getInputStruc().getISimulationId());
        assertEquals(6983663, applyOverpaymentRequestArgumentCaptor.getValue().getCreateWsPayReceivedRequest().getRequest().getInputStruct().getIo32129().getISimulatorId());

    }

    @Test
    void testTrueIfSimulationFails() throws IOException, ConnectionException {

        when(mqSimulationClient.simulate(anyString(), any(ANMFSimulationRequest.class), any(AnmfRegion.class), anyString())).thenReturn(TestDataCreator.generateSimulationResponseKo());
        doNothing().when(mqApplyOverpaymentClient).pay(anyString(), any(ApplyOverpaymentRequest.class), anyString(), anyString());

        assertTrue(applyOverpaymentService.apply(TestDataCreator.generatPaymentsMqMessage(), "jwtToken"));

    }
}