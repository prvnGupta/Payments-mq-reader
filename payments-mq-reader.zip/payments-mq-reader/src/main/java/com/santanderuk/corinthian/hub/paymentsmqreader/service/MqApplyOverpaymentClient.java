package com.santanderuk.corinthian.hub.paymentsmqreader.service;

import com.santanderuk.corinthian.services.commons.anmfclient.io.applyoverpaymenttransaction.ApplyOverpaymentRequest;
import com.santanderuk.corinthian.services.commons.anmfclient.io.applyoverpaymenttransaction.ApplyOverpaymentResponse;
import com.santanderuk.corinthian.services.commons.config.ApiManagerConfig;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import static org.springframework.http.HttpHeaders.ACCEPT;
import static org.springframework.http.HttpHeaders.CONTENT_TYPE;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@Slf4j
@Component
public class MqApplyOverpaymentClient {

    public static final ConnectionException.Type ANMF_UNAVAILABLE = ConnectionException.Type.ANMF_UNAVAILABLE;
    private final RestTemplate restTemplate;
    private final ApiManagerConfig apiManagerConfig;

    @Autowired
    public MqApplyOverpaymentClient(RestTemplate restTemplate, ApiManagerConfig apiManagerConfig) {
        this.restTemplate = restTemplate;
        this.apiManagerConfig = apiManagerConfig;
    }

    public void pay(final String url, final ApplyOverpaymentRequest request, String eMergeUser, String jwtToken) throws ConnectionException {
        MultiValueMap<String, String> headers = generateHttpHeaders(eMergeUser, jwtToken);
        HttpEntity<ApplyOverpaymentRequest> httpEntity = new HttpEntity<>(request, headers);
        ResponseEntity<ApplyOverpaymentResponse> responseEntity;

        try {
            log.info("ApplyOverpaymentClient - > Calling ANMF apply payment microservice: {}", url);
            log.debug("ApplyOverpaymentClient - > Sending object: {}", request);

            responseEntity = restTemplate.postForEntity(
                    url,
                    httpEntity,
                    ApplyOverpaymentResponse.class
            );
            log.info("ApplyOverpaymentClient - > Call to ANMF apply payment microservice was OK");
            log.debug("JSON Response -> {}", responseEntity.getBody());
        } catch (RestClientException e) {
            log.error("ApplyOverpaymentClient -> error while connecting to ANMF Simulation microservice");
            throw new ConnectionException(ANMF_UNAVAILABLE, e);
        }
    }

    private HttpHeaders generateHttpHeaders(String eMergeUser, String jwtToken) {
        final HttpHeaders headers = new HttpHeaders();
        headers.add("x-ibm-client-id", apiManagerConfig.getClientIdValue());
        headers.add("x-ibm-client-secret", apiManagerConfig.getClientSecretValue());
        headers.add("Emerge-User", eMergeUser);
        headers.add("Authorization", jwtToken);
        headers.add(ACCEPT, APPLICATION_JSON_VALUE);
        headers.add(CONTENT_TYPE, APPLICATION_JSON_VALUE);
        return headers;
    }
}
