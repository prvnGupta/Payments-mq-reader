package com.santanderuk.corinthian.hub.paymentsmqreader.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.santanderuk.corinthian.hub.paymentsmqreader.config.PaymentsMqReaderConfig;
import com.santanderuk.corinthian.hub.paymentsmqreader.jwttoken.JwtTokenService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.BDDMockito.given;

@ExtendWith(MockitoExtension.class)
public class MqConsumerServiceTest {

    MqConsumerService mqConsumerService;

    @Mock
    PaymentsMqReaderConfig config;
    @Mock
    ObjectMapper objectMapper;
    @Mock
    JwtTokenService jwtTokenService;
    @Mock
    ApplyOverpaymentService applyOverpaymentService;

    @BeforeEach
    public void setUp() {
        mqConsumerService = new MqConsumerService(objectMapper, config, jwtTokenService, applyOverpaymentService);

    }

    @Test
    public void paymentsMqReader_ReadMessage_PaymentSuccess_OK() throws Exception {

        given(config.getMaxMsg()).willReturn(0);
        given(config.getVirtualHost()).willReturn("");
        given(config.getMqUsername()).willReturn("guest");
        given(config.getMqPassword()).willReturn("guest");
        given(config.getGassMqHost()).willReturn("rabbitmq-testing-server");
        given(config.getMqPort()).willReturn(5672);
        mqConsumerService.readMessage();
    }

}

