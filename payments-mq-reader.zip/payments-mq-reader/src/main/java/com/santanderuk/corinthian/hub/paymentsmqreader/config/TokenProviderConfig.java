package com.santanderuk.corinthian.hub.paymentsmqreader.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

/**
 * Created by c0245070 on 19/09/2017.
 */

@Configuration
@Getter
@Setter
public class TokenProviderConfig {

    @Value("${url.jwtFromOAuth}")
    private String jwtFromOAuthUrl;
    @Value("${url.oAuthFromCredentials}")
    private String oAuthFromCredentials;
    @Value("${credentials.usr}")
    private String username;
    @Value("${credentials.pwd}")
    private String password;
    @Value("${credentials.clientId}")
    private String clientId;
    @Value("${credentials.clientIdSecret}")
    private String clientIdSecret;
    @Value("${credentials.grantType}")
    private String grantType;
    @Value("${credentials.scope}")
    private String scope;

}
