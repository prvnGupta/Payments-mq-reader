package com.santanderuk.corinthian.hub.paymentsmqreader.functional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.context.ActiveProfiles;

import static com.jayway.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;


@ActiveProfiles("test")
public class HealthFunctionalTest extends FunctionalTest {

    String healthUrl;
    String healthzUrl;

    @BeforeEach
    public void setup() {
        healthUrl = String.format("http://localhost:%s/payments-mq-reader/health", serverPort);
        healthzUrl = String.format("http://localhost:%s/payments-mq-reader/healthz", serverPort);
    }

    @Test
    public void customHealthReturnsUp() {

        given().
                when().
                get(healthUrl).
                then().
                statusCode(200).
                and().
                body(equalTo("Up"));
    }

    @Test
    public void customHealthZReturnsUp() {

        given().
                when().
                get(healthzUrl).
                then().
                statusCode(200).
                and().
                body(equalTo("Up"));
    }

}
