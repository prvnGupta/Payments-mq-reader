package com.santanderuk.corinthian.hub.paymentsmqreader.jwttoken;

import com.santanderuk.corinthian.hub.paymentsmqreader.config.TokenProviderConfig;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

@Component
public class HeaderCreator {

    private static final MediaType APPLICATION_JSON = MediaType.APPLICATION_JSON;
    private static final MediaType APPLICATION_FORM_URLENCODED = MediaType.APPLICATION_FORM_URLENCODED;

    private final TokenProviderConfig tokenProviderConfig;

    public HeaderCreator(TokenProviderConfig tokenProviderConfig) {
        this.tokenProviderConfig = tokenProviderConfig;
    }

    public HttpHeaders jwtFromOauth(final String oAuth) {
        final HttpHeaders headers = new HttpHeaders();
        headers.setContentType(APPLICATION_JSON);
        headers.add("authorization", "Bearer " + oAuth);
        headers.add("X-IBM-Client-Id", tokenProviderConfig.getClientId());

        return headers;
    }

    public HttpHeaders oAuthFromCredentials() {
        final HttpHeaders headers = new HttpHeaders();
        headers.setContentType(APPLICATION_FORM_URLENCODED);
        return headers;
    }
}
