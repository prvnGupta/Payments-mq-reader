package com.santanderuk.corinthian.hub.paymentsmqreader.jwttoken;

import com.santanderuk.corinthian.hub.paymentsmqreader.config.TokenProviderConfig;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

@Component
public class FormUrlEncodedCreator {

    private final TokenProviderConfig tokenProviderConfig;

    public FormUrlEncodedCreator(TokenProviderConfig tokenProviderConfig) {
        this.tokenProviderConfig = tokenProviderConfig;

    }

    public MultiValueMap<String, String> get() {
        final MultiValueMap<String, String> map = new LinkedMultiValueMap<>();

        map.add("grant_type", tokenProviderConfig.getGrantType());
        map.add("client_id", tokenProviderConfig.getClientId());
        map.add("scope", tokenProviderConfig.getScope());
        map.add("username", tokenProviderConfig.getUsername());
        map.add("password", tokenProviderConfig.getPassword());
        map.add("client_secret", tokenProviderConfig.getClientIdSecret());

        return map;
    }
}
