package com.santanderuk.corinthian.hub.paymentsmqreader;

import com.santanderuk.corinthian.hub.paymentsmqreader.service.PaymentsMqMessage;
import com.santanderuk.corinthian.services.commons.anmfclient.io.applyoverpaymenttransaction.ApplyOverpaymentResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.simulations.ANMFSimulationResponse;

import java.io.IOException;

public class TestDataCreator {

    public static ANMFSimulationResponse generateSimulationResponseOK() throws IOException {
        return FixtureReader.get("simulation/default-ok-response.json", ANMFSimulationResponse.class);
    }

    public static ANMFSimulationResponse generateSimulationResponseKo() throws IOException {
        return FixtureReader.get("simulation/default-ko-response.json", ANMFSimulationResponse.class);
    }

    public static ApplyOverpaymentResponse generateApplyOverpaymentResponseOK() throws IOException {
        return FixtureReader.get("applyoverpayment/default-ok-response.json", ApplyOverpaymentResponse.class);
    }

    public static ApplyOverpaymentResponse generateApplyOverpaymentResponseKo() throws IOException {
        return FixtureReader.get("applyoverpayment/default-ko-response.json", ApplyOverpaymentResponse.class);
    }

    public static PaymentsMqMessage generatPaymentsMqMessage() throws IOException {
        return FixtureReader.get("payments-mq-message.json", PaymentsMqMessage.class);
    }
}
