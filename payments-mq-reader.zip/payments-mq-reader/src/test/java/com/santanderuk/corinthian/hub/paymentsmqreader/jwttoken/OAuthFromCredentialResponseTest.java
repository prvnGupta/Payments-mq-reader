package com.santanderuk.corinthian.hub.paymentsmqreader.jwttoken;


import org.junit.jupiter.api.Test;
import org.springframework.test.context.ActiveProfiles;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ActiveProfiles("test")

public class OAuthFromCredentialResponseTest {

    @Test
    public void testFields() {
        OAuthFromCredentialResponse response = new OAuthFromCredentialResponse();

        response.setTokenType("token_type_value");
        response.setAccessToken("access_token_value");
        response.setExpiresIn(1);
        response.setConsentedOn(2);
        response.setScope("scope_value");
        response.setRefreshToken("refresh_token_value");
        response.setRefreshTokenExpiresIn(3);
        response.setError("error_value");

        assertEquals("token_type_value", response.getTokenType());
        assertEquals("access_token_value", response.getAccessToken());
        assertEquals(1, response.getExpiresIn());
        assertEquals(2, response.getConsentedOn());
        assertEquals("scope_value", response.getScope());
        assertEquals("refresh_token_value", response.getRefreshToken());
        assertEquals(3, response.getRefreshTokenExpiresIn());
        assertEquals("error_value", response.getError());

        assertEquals("{\"accessToken\":\"access_token_value\",\"consentedOn\":2,\"error\":\"error_value\",\"expiresIn\":1,\"refreshToken\":\"refresh_token_value\",\"refreshTokenExpiresIn\":3,\"scope\":\"scope_value\",\"tokenType\":\"token_type_value\"}", response.toString());
    }

}
