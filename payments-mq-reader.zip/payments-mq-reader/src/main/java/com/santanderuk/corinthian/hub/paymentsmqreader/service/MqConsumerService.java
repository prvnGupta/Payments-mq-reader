package com.santanderuk.corinthian.hub.paymentsmqreader.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.GetResponse;
import com.santanderuk.corinthian.hub.paymentsmqreader.config.PaymentsMqReaderConfig;
import com.santanderuk.corinthian.hub.paymentsmqreader.jwttoken.JwtTokenService;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

@Component
@Slf4j
public class MqConsumerService {

    private final ObjectMapper objectMapper;
    private final PaymentsMqReaderConfig config;
    private final JwtTokenService jwtTokenService;
    private final ApplyOverpaymentService applyOverpaymentService;

    @Autowired
    public MqConsumerService(ObjectMapper objectMapper, PaymentsMqReaderConfig config, JwtTokenService jwtTokenService, ApplyOverpaymentService applyOverpaymentService) {
        this.objectMapper = objectMapper;
        this.config = config;
        this.jwtTokenService = jwtTokenService;
        this.applyOverpaymentService = applyOverpaymentService;
    }


    public void readMessage() throws GeneralException {
        Channel channel = null;
        ConnectionFactory factory;
        Connection conn = null;
        try {

            factory = getConnectionFactory();

            log.debug("Payments mq Reader - > Connecting to MQ");
            conn = factory.newConnection();
            log.info("CONNECTION CREATED");

            log.info("Payments mq Reader - > Creating Channel");
            channel = conn.createChannel();

            int maxMsg = config.getMaxMsg();

            for (; maxMsg > 0; maxMsg--) {
                GetResponse result = channel.basicGet(config.getPaymentsMqQueue(), false);

                if (result != null) {
                    String message = new String(result.getBody(), StandardCharsets.UTF_8);
                    log.info("Message received");
                    log.debug("Message received: {}", message);

                    String jwtToken = getJwtToken(channel, result);

                    if (!"".equalsIgnoreCase(jwtToken)) {
                        if (applyPaymentInAnmf(message, jwtToken)) {
                            channel.basicAck(result.getEnvelope().getDeliveryTag(), false);
                            log.info("Message removed from queue");
                        } else {
                            log.info("Message will be reprocessed. Not able to process message");
                            channel.basicNack(result.getEnvelope().getDeliveryTag(), false, true);
                        }
                    }
                } else {
                    log.info("No messages in queue");
                }
            }
            long anmfInterval = config.getAnmfInterval();
            log.info("Sleeping for {} milliseconds", anmfInterval);
            Thread.sleep(anmfInterval);
        } catch (Exception e) {
            log.error("An error occurred while reading a msg from mq.", e);
            Thread.currentThread().interrupt();
            throw new GeneralException("PAYMENTS_MQ_EXC", "Exception while reading from the queue");
        } finally {
            log.info("close connection to rabbit mq");
            disconnectFromQueue(channel, conn);
        }
    }

    private String getJwtToken(Channel channel, GetResponse result) throws IOException {
        String jwtToken = "";
        try {
            jwtToken = jwtTokenService.getToken();
        } catch (GeneralException generalException) {
            log.error("An error occurred while getting token.", generalException);
            log.info("Message will be reprocessed. Not able to get token");
            channel.basicNack(result.getEnvelope().getDeliveryTag(), false, true);

        }
        return jwtToken;
    }

    @NotNull
    private ConnectionFactory getConnectionFactory() {
        ConnectionFactory factory;
        factory = new ConnectionFactory();

        factory.setUsername(config.getMqUsername());
        factory.setPassword(config.getMqPassword());
        factory.setHost(config.getGassMqHost());
        factory.setPort(config.getMqPort());
        if (config.getVirtualHost() != null && !config.getVirtualHost().trim().equalsIgnoreCase("")) {
            factory.setVirtualHost(config.getVirtualHost());
        }
        log.debug("Username:    {}", config.getMqUsername());
        log.debug("Password informed");
        log.debug("Host:        {}", config.getGassMqHost());
        log.debug("Port:        {}", config.getMqPort());
        log.debug("VirtualHost: {}", config.getVirtualHost());
        return factory;
    }


    public void disconnectFromQueue(Channel channel, Connection conn) {
        if (channel != null && conn != null) {
            try {
                channel.close();
                conn.close();
            } catch (Exception e) {
                log.error("ERROR:- exception caught when trying to disconnectFromQueue. {} ", e.getCause(), e);
            }
        }
    }

    private boolean applyPaymentInAnmf(String message, String jwtToken) {
        try {
            PaymentsMqMessage paymentsMqMessage = stringToANMFPaymentsRequest(message);
            return applyOverpaymentService.apply(paymentsMqMessage, jwtToken);
        } catch (IOException e) {
            log.error("ERROR, Exception parsing Msg from Mq", e);
            return true;
        } catch (Exception e) {
            log.error("ERROR, Exception whilst trying to call API Manager", e);
            return false;
        }
    }

    private PaymentsMqMessage stringToANMFPaymentsRequest(String message) throws IOException {
        PaymentsMqMessage paymentsMqMessage;
        try {
            paymentsMqMessage = objectMapper.readValue(message, PaymentsMqMessage.class);
        } catch (IOException e) {
            log.debug("ERROR:- Exception while parsing message from queue", e);
            throw e;
        }
        return paymentsMqMessage;
    }
}
