package com.santanderuk.corinthian.hub.paymentsmqreader;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.springframework.core.io.ClassPathResource;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;

@Slf4j
public class FixtureReader {


    public static <T> T get(String filename, final Class<T> cls) throws IOException {
        String fileContent = readFileContents(filename);
        return convertResponseToObject(fileContent, cls);
    }

    public static String readFileContents(String filename) {
        InputStream resource;
        String fixtureContents = "";
        try {
            resource = new ClassPathResource(String.format("/fixtures/%s", filename)).getInputStream();
            fixtureContents = IOUtils.toString(resource, Charset.defaultCharset());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return fixtureContents;
    }

    private static <T> T convertResponseToObject(final String fileContent, final Class<T> cls) throws IOException {
        return (new ObjectMapper()).readValue(fileContent, cls);
    }
}
