package com.santanderuk.corinthian.hub.paymentsmqreader;

import com.santanderuk.corinthian.hub.paymentsmqreader.service.PaymentsMqReaderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaymentsMqReaderApplication implements CommandLineRunner {

    @Autowired
    private PaymentsMqReaderService paymentsMqReaderService;


    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(PaymentsMqReaderApplication.class);
        app.run(args);
    }

    public void run(String... args) throws Exception {
        Thread paymentsMqReaderThread = new Thread(paymentsMqReaderService);
        Thread.sleep(3000);
        paymentsMqReaderThread.start();
    }

}
