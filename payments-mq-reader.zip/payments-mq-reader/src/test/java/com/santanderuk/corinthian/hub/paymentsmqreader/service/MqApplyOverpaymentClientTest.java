package com.santanderuk.corinthian.hub.paymentsmqreader.service;

import com.santanderuk.corinthian.hub.paymentsmqreader.TestDataCreator;
import com.santanderuk.corinthian.services.commons.anmfclient.io.applyoverpaymenttransaction.ApplyOverpaymentRequest;
import com.santanderuk.corinthian.services.commons.anmfclient.io.applyoverpaymenttransaction.ApplyOverpaymentResponse;
import com.santanderuk.corinthian.services.commons.config.ApiManagerConfig;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.Objects;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class MqApplyOverpaymentClientTest {
    MqApplyOverpaymentClient mqApplyOverpaymentClient;

    @Mock
    RestTemplate restTemplate;

    @Mock
    ApiManagerConfig apiManagerConfig;

    @BeforeEach
    void setUp() {
        mqApplyOverpaymentClient = new MqApplyOverpaymentClient(restTemplate, apiManagerConfig);
        when(apiManagerConfig.getClientIdValue()).thenReturn("clientId");
        when(apiManagerConfig.getClientSecretValue()).thenReturn("clientSecret");
    }

    @Test
    void testHappyPath() throws ConnectionException, IOException {

        ArgumentCaptor<HttpEntity> argumentCaptorHttpEntity = ArgumentCaptor.forClass(HttpEntity.class);
        when(restTemplate.postForEntity(anyString(), any(HttpEntity.class), eq(ApplyOverpaymentResponse.class))).thenReturn(generateOKResponseEntity());
        mqApplyOverpaymentClient.pay("/sanuk/internal/mortgage-payments/payments", new ApplyOverpaymentRequest(), "eMergeUser2", "jwtToken");

        Mockito.verify(restTemplate, times(1)).postForEntity(anyString(), argumentCaptorHttpEntity.capture(), eq(ApplyOverpaymentResponse.class));

        assertEquals("eMergeUser2", Objects.requireNonNull(argumentCaptorHttpEntity.getValue().getHeaders().get("Emerge-User")).get(0));
        assertEquals("jwtToken", Objects.requireNonNull(argumentCaptorHttpEntity.getValue().getHeaders().get("Authorization")).get(0));

    }

    @Test
    void testSimulationRestClientExc() {
        when(restTemplate.postForEntity(anyString(), any(HttpEntity.class), eq(ApplyOverpaymentResponse.class))).thenThrow(RestClientException.class);
        assertThrows(ConnectionException.class, () -> mqApplyOverpaymentClient.pay("simulationUrl/{region}/simulation)", new ApplyOverpaymentRequest(), "eMergeUser", "jwtToken"));
    }

    @Test
    void testSimulationErrorBody() throws ConnectionException, IOException {
        when(restTemplate.postForEntity(anyString(), any(HttpEntity.class), eq(ApplyOverpaymentResponse.class))).thenReturn(generateKoResponseEntity());
        mqApplyOverpaymentClient.pay("simulationUrl/{region}/simulation)", new ApplyOverpaymentRequest(), "eMergeUser", "jwtToken");
    }

    private ResponseEntity<ApplyOverpaymentResponse> generateOKResponseEntity() throws IOException {
        ApplyOverpaymentResponse applyOverpaymentResponse = TestDataCreator.generateApplyOverpaymentResponseOK();
        return new ResponseEntity<>(applyOverpaymentResponse, HttpStatus.OK);
    }

    private ResponseEntity<ApplyOverpaymentResponse> generateKoResponseEntity() throws IOException {
        ApplyOverpaymentResponse applyOverpaymentResponse = TestDataCreator.generateApplyOverpaymentResponseKo();
        return new ResponseEntity<>(applyOverpaymentResponse, HttpStatus.OK);
    }
}
